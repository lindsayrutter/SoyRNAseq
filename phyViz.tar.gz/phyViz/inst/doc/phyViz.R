
## ------------------------------------------------------------------------
library(phyViz)
library(plyr)
library(reshape2)
library(ggplot2)
library(stringr)
library(igraph)
load(system.file("doc","example","tree.rda",package="phyViz"))


## ------------------------------------------------------------------------
head(tree)


